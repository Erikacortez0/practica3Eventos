﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_3EVENTOS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //utilizar la clase openfiledialog para visualizar la ventana 
            OpenFileDialog abrir = new OpenFileDialog();

            abrir.Filter = "JPGDE (*.JPG) |*.JPG";

            //validamos la ventana y la mostramos
            //showDialog abre una ventana, el if  valida nuestra respuesta
            //en la ventana
            if (abrir.ShowDialog() == DialogResult.OK)
            {
                // agregamos las validaciones sobre ventana img
                //obteneniendo la ruta de la imagen  y el nombre del archivo

                pictureBox1.Image = Image.FromFile(abrir.FileName);

            }
            else
            {

            }
        }
        private bool isImg = true;

        private void button2_Click(object sender, EventArgs e)
        {
            if (isImg)
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\corte\\Downloads\\imagen 4.jpg");
                isImg = false;


            }
            else
            {
                pictureBox2.Image = Image.FromFile("C:\\Users\\corte\\Downloads\\imagen3.jpg");
                isImg = true;
            }
        }
    }
    
}
