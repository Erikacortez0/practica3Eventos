﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3DePracticas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool IsImg = true;
        private void timer1_Tick(object sender, EventArgs e)
        {
            // agregamos lo que es timer su funcionalidad para que las imagenes cambien cada 3 segundo 
            if (IsImg == true)
            {
                //aqui agregamos las rutas de acceso de las respectivas imagenes para que se puedan mostrar 
                //al correr el programa
                pictureBox1.Image = Image.FromFile("C:\\Users\\corte\\Downloads\\images (1).jpg");
                IsImg = false;
            }
            else
            {
                pictureBox1.Image = Image.FromFile("C:\\Users\\corte\\Downloads\\images (2).jpg");
                IsImg = true;
            }
        }
    }
}
